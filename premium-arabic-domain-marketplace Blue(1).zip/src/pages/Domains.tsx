import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { getCategories, getDomains } from "../lib/db";
import DomainCard from "../components/DomainCard";

const TLDs = [".com", ".net", ".org", ".io", ".co"];
type SortOpt = "newest" | "price-asc" | "price-desc" | "popular";

export default function Domains() {
  const [params, setParams] = useSearchParams();
  const allDomains = useMemo(() => getDomains(), []);
  const categories = useMemo(() => getCategories(), []);

  const [q, setQ] = useState(params.get("q") ?? "");
  const [cat, setCat] = useState(params.get("cat") ?? "");
  const [tld, setTld] = useState(params.get("tld") ?? "");
  const [maxLen, setMaxLen] = useState<number>(Number(params.get("len")) || 12);
  const [sort, setSort] = useState<SortOpt>((params.get("sort") as SortOpt) || "newest");

  useEffect(() => {
    const next = new URLSearchParams();
    if (q) next.set("q", q);
    if (cat) next.set("cat", cat);
    if (tld) next.set("tld", tld);
    if (maxLen !== 12) next.set("len", String(maxLen));
    if (sort !== "newest") next.set("sort", sort);
    setParams(next, { replace: true });
  }, [q, cat, tld, maxLen, sort, setParams]);

  const results = useMemo(() => {
    let list = allDomains.filter((d) => d.status === "AVAILABLE");
    if (q) {
      const needle = q.toLowerCase();
      list = list.filter(
        (d) => `${d.name}${d.tld}`.toLowerCase().includes(needle) || d.arabicName?.includes(q)
      );
    }
    if (cat) {
      const c = categories.find((c) => c.slug === cat);
      if (c) list = list.filter((d) => d.categoryId === c.id);
    }
    if (tld) list = list.filter((d) => d.tld === tld);
    list = list.filter((d) => d.name.length <= maxLen);

    switch (sort) {
      case "price-asc":
        list = [...list].sort((a, b) => (a.price ?? Infinity) - (b.price ?? Infinity));
        break;
      case "price-desc":
        list = [...list].sort((a, b) => (b.price ?? -1) - (a.price ?? -1));
        break;
      case "popular":
        list = [...list].sort((a, b) => b.views - a.views);
        break;
      default:
        list = [...list].sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
    }
    return list;
  }, [allDomains, categories, q, cat, tld, maxLen, sort]);

  function clearFilters() {
    setQ(""); setCat(""); setTld(""); setMaxLen(12); setSort("newest");
  }

  return (
    <div className="max-w-7xl mx-auto px-5 lg:px-8 py-12">
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="text-[#5bc9cc] text-xs tracking-[0.3em] uppercase mb-2 font-semibold">
          The Catalogue
        </div>
        <h1 className="text-4xl md:text-5xl font-black text-[#0a1a3a] section-title-line">جميع النطاقات</h1>
        <p className="mt-4 text-gray-500 max-w-xl">
          استكشف مجموعتنا الكاملة من النطاقات العربية الفاخرة. استخدم الفلاتر لتجد ما يناسب رؤيتك.
        </p>
      </motion.div>

      <div className="mt-10 grid lg:grid-cols-[280px_1fr] gap-8">
        {/* Sidebar */}
        <aside className="space-y-6">
          <div className="luxury-card rounded-2xl p-5">
            <label className="text-xs uppercase tracking-widest text-gray-400">بحث</label>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="اسم النطاق..."
              className="mt-2 w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-2.5 outline-none focus:border-[#91eff2] focus:shadow-[0_0_0_3px_rgba(145,239,242,0.15)] text-[#0a1a3a]"
            />
          </div>

          <div className="luxury-card rounded-2xl p-5">
            <div className="text-xs uppercase tracking-widest text-gray-400 mb-3">الفئة</div>
            <div className="space-y-2">
              <button
                onClick={() => setCat("")}
                className={`w-full text-right px-3 py-2 rounded-lg text-sm transition ${
                  !cat ? "bg-[#91eff2]/10 text-[#2ab0b4] border border-[#91eff2]/30 font-semibold" : "text-gray-500 hover:bg-gray-50"
                }`}
              >
                الكل
              </button>
              {categories.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setCat(c.slug)}
                  className={`w-full text-right px-3 py-2 rounded-lg text-sm transition ${
                    cat === c.slug
                      ? "bg-[#91eff2]/10 text-[#2ab0b4] border border-[#91eff2]/30 font-semibold"
                      : "text-gray-500 hover:bg-gray-50"
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          <div className="luxury-card rounded-2xl p-5">
            <div className="text-xs uppercase tracking-widest text-gray-400 mb-3">الامتداد (TLD)</div>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setTld("")}
                className={`px-3 py-1.5 rounded-full text-xs border ${
                  !tld ? "border-[#91eff2]/50 text-[#2ab0b4] bg-[#91eff2]/5 font-semibold" : "border-gray-200 text-gray-500"
                }`}
              >
                الكل
              </button>
              {TLDs.map((t) => (
                <button
                  key={t}
                  onClick={() => setTld(t === tld ? "" : t)}
                  className={`px-3 py-1.5 rounded-full text-xs border ${
                    tld === t ? "border-[#91eff2]/50 text-[#2ab0b4] bg-[#91eff2]/5 font-semibold" : "border-gray-200 text-gray-500 hover:border-gray-300"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div className="luxury-card rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="text-xs uppercase tracking-widest text-gray-400">الطول الأقصى</div>
              <div className="text-[#2ab0b4] font-bold text-sm">{maxLen} حرف</div>
            </div>
            <input
              type="range"
              min={3}
              max={12}
              value={maxLen}
              onChange={(e) => setMaxLen(Number(e.target.value))}
              className="w-full accent-[#91eff2]"
            />
          </div>

          <button
            onClick={clearFilters}
            className="w-full btn-ghost py-2.5 rounded-lg text-sm"
          >
            مسح الفلاتر
          </button>
        </aside>

        {/* Results */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <div className="text-sm text-gray-500">
              <span className="text-[#0a1a3a] font-bold">{results.length}</span> نطاق متاح
            </div>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortOpt)}
              className="bg-white border border-gray-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-[#91eff2] text-[#0a1a3a]"
            >
              <option value="newest">الأحدث</option>
              <option value="price-asc">السعر: من الأقل</option>
              <option value="price-desc">السعر: من الأعلى</option>
              <option value="popular">الأكثر مشاهدة</option>
            </select>
          </div>

          {results.length === 0 ? (
            <div className="luxury-card rounded-2xl p-12 text-center">
              <div className="text-4xl mb-3">✦</div>
              <p className="text-gray-500">
                لا توجد نطاقات تطابق الفلاتر الحالية.
              </p>
              <button onClick={clearFilters} className="mt-4 btn-ghost px-5 py-2 rounded-lg text-sm">
                إعادة الضبط
              </button>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {results.map((d, i) => (
                <DomainCard key={d.id} domain={d} index={i} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
